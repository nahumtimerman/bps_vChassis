from sandbox_scripts.environment.teardown.teardown_script import EnvironmentTeardown


def main():
    EnvironmentTeardown().execute()

if __name__ == "__main__":
    main()
